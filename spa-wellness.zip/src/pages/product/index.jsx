import ProductDetailsView from "../../sections/product-details/product-details-view";

export default function Page() {
  return (
    <>
     <ProductDetailsView />
    </>
  );
}
