import PaymentView from "src/sections/checkout/view/payment-view";

export default function Page() {
  return (
    <>
        <PaymentView />
    </>
  );
}
