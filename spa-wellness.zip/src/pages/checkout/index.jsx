import CheckoutView from "../../sections/checkout/view/checkout-view";

export default function Page() {
  return (
    <>
        <CheckoutView />
    </>
  );
}
