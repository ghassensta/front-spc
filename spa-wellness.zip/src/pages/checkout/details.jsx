import CheckoutDetails from "src/sections/checkout/view/checkout-details";

export default function Page() {
  return (
    <>
        <CheckoutDetails />
    </>
  );
}
