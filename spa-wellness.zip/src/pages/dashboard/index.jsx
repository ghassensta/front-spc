import DashboardView from "src/sections/dashboard/root/dashboard-view";

export default function Page() {
  return (
    <>
        <DashboardView />
    </>
  );
}
