import CommandesViewPage from "src/sections/dashboard/commandes/view/commandes-view-page";

export default function Page() {
    return (
      <>
          <CommandesViewPage />
      </>
    );
  }
  