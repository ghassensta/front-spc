import ProfileDetails from "src/sections/dashboard/details/profile-details";

export default function Page() {
    return (
      <ProfileDetails />
    );
  }
  