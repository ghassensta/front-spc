import LoginPageView from "src/sections/auth/view/login-page-view";

export default function Page() {
  return (
    <>
        <LoginPageView />
    </>
  );
}
