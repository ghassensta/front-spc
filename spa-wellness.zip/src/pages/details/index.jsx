
import SpaDetailsView from "../../sections/spa-details/spa-details-view";

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
     <SpaDetailsView />
    </>
  );
}
