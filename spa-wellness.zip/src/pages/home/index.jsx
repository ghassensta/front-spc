

// ----------------------------------------------------------------------

import HomeView from "../../sections/home/home-view";

export default function Page() {
  return (
    <>
        <HomeView />
    </>
  );
}
