import drops from './drops.png';
import pool from './pool.png';
import sauna from './sauna.png';
import treatement from './treatment.png';

export { drops, pool, sauna, treatement };