import illustration1 from './Illustration_1.png';
import illustration2 from './Illustration_2.png';

export { illustration1, illustration2 };