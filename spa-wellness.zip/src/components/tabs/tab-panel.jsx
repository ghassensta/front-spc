import React from "react";

export default function TabPanel({ content }) {
  return <p className="text-gray-700">{content}</p>;
}
